<form method="post" action="" enctype="multipart/form-data">
                        <!-- save button -->
                        <button class="bg-transparent  md:absolute right-0 -top-10 hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">
                        Simpan Video
                        </button>

                        <input type="number" name="element" readonly value="3" id="element" class="hidden">    

                        <section id="main-element" class="mb-10 mt-2">
                        <div class="mx-auto text-center mb-4">
                            <input required class="relative w-full md:w-[80%] px-4 outline-blue-500 py-2 left-0 right-0 mx-auto border text-center text-2xl font-semibold rounded-lg" type="text" name="artikel-title" id="artikel-title" placeholder="Judul Video Anda" value="<?=$pbl->judul_pbl?>">
                            <?php echo form_error('artikel-title', '<h1 class="absolute ml-10 bg-black text-md mt-20"><font class="text-blue-100 mt-20"></font></h1>'); ?>
                        </div>
                        
                        <!--Element 1-->
                        <div id="element-1" class="mb-5 flex flex-wrap">
                            <!-- left image -->
                            <div class="mb-6 w-full shrink-0 grow-0 basis-auto lg:mb-0 lg:w-6/12 lg:pr-6">
                            <div class="relative">
                                <div class="ripple mb-2 relative overflow-hidden rounded-lg border h-96 bg-cover bg-[50%] bg-no-repeat shadow-lg dark:shadow-black/20">
                                    <div id="text-1" class="absolute w-full text-center mt-40 font-semibold text-gray-400/70 text-2xl h-full">
                                        <h2>Silahkan Memilih Gambar</h2> <span class="text-sm font-normal">Maximal 5Mb</span>
                                    </div>
                                    <img id="preview-image-1" src="<?=base_url('assets/images/thumbnail/'.$pbl->sampul);?>" alt="Preview Gambar" class="w-full h-full">
                                    <div class="absolute top-0 right-0 bottom-0 left-0 h-full w-full overflow-hidden bg-[hsl(0,0%,98.4%,0.2)] bg-fixed opacity-0 transition duration-300 ease-in-out hover:opacity-100"></div>
                                </div>
                                <div class="z-50 mx-auto">
                                    <input type="file" accept=".jpeg, .jpg, .png" name="Image-1" class="hidden" id="Image-1" onchange="previewImage(1)">
                                    <label class="bg-transparent md:absolute right-0 hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded" for="Image-1">Pilih Sampul Video</label>
                                </div>
                                </div>
                            </div>
                            <!-- left image -->

                            <!-- left deskription -->
                            <div class="w-full shrink-0 grow-0 basis-auto lg:w-6/12 lg:pl-6">
                            
                            <!-- kategori -->
                            <div class="grid grid-cols-2 gap-2">
                            <div class="mb-2">
                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Jurusan</div>
                                <select id="artikel-kategori" name="artikel-kategori" class="bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option disabled>Pilih Jurusan</option>
                                    <option value="<?=$pbl->jurusan?>"><?=$pbl->jurusan?></option>
                                    <option disabled>---------------</option>
                                    <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                                    <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                                    <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                                    <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                                </select>
                            </div>
                            <div class="mb-2">
                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Status Vidio</div>
                                <input type="text" value="<?=$status?>" readonly class="border border-gray-300 text-gray-900 text-md rounded-lg outline-none block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            </div>

                            </div>
                            <div class="grid grid-cols-2 gap-2">
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Dosen Pengampuh MK</div>
                                    <input type="text" id="input-dosen-pengampuh" class="hidden" required readonly value="<?=$pembina->userid?>" name="input-dosen-pengampuh">
                                    <input type="text" value="<?=$pembina->firstname.' '.$pembina->lastname?>" readonly name="dosen-pengampuh" placeholder="Contoh: Object Oriented Programming" required class="border outline-none border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mitra</div>
                                    <input type="text" value="<?=$pbl->nama_mitra?>" name="nama-mitra" placeholder="Contoh: Politeknik Negeri Manado" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                            </div>

                            <!-- Deskripsi -->
                            <div class="mb-3">
							<div class="mb-3">
                                    <textarea required name="artikel-deskripsi-1" id="artikel-deskripsi-1" cols="30" rows="16" placeholder="Deskripsi Video Anda.."><?=html_entity_decode($pbl->deskripsi)?></textarea>
                                </div>
                            </div>
                            
                            </div>

                            <div class="w-full h-auto relative">
                                <input type="number" value="<?=$jumlah?>" class="hidden" name="jumlah-mahasiswa" id="jumlah-mahasiswa">
                                <div class="text-gray-600 mb-4 font-bold uppercase">Mahasiswa Terlibat</div>
                                    <div id="mahasiswa-terlibat" class="grid grid-cols-3 mb-4 gap-4">
                                        <?php $index=0; foreach ($mahasiswa->result() as $item) { $index++;?>
                                            <input type="text" value="<?=$item->no?>" class="hidden" name="no-<?=$index?>" id="no-<?=$index?>">
                                            <div id='nama-<?=$index?>' class="mb-2">
                                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mahasiswa <?=$index?></div>
                                            <input type="text" value="<?=$item->nama?>" placeholder="Nama Mahasiswa <?=$index?>" id="nama-mahasiswa-<?=$index?>" name="nama-mahasiswa-<?=$index?>" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                            </div>
                                            <div id='program-studi-<?=$index?>' class="mb-2">
                                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Program Studi</div>
                                                <select id="program-studi-<?=$index?>" name="program-studi-<?=$index?>" class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                    <option value="<?=$item->prodi?>"><?=$item->prodi?></option>
                                                    <option disabled>---------------</option>
                                                    <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                                                    <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                                                    <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                                                    <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                                                </select>
                                            </div>
                                            <div id='nim-<?=$index?>' class="mb-2">
                                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nim</div>
                                                <input type="text" value="<?=$item->nim?>" id="nim-mahasiswa-<?=$index?>" name="nim-mahasiswa-<?=$index?>" placeholder="Contoh: 21024137" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                            </div>
                                        <?php }?>
                                    </div>
                                    </div>

                                </div>

                            <div class="mb-2">
                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Original Link</div>
                                <input name="original-link" id="original-link" type="text" placeholder="Contoh: <iframe width='560' height='315' src='https://www.youtube.com/embed/fSE4laODlng?si=t_WqD1XcIv6A01d5' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe>" class="relative w-full px-1 outline-blue-500 py-3 border text-left pl-3 text-md font-normal rounded-lg">
                           <div class="mt-4 mb-4">
                           <a onclick="extractLink();" class="bg-transparent mx-auto cursor-pointer hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">
                                Extract Link
                                </a>
                           </div>
                            </div>
                         
                            <div>
                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Link</div>
                                <input name="link" value="<?=$pbl->link?>" id="link" required type="text" placeholder="Contoh: https://www.youtube.com/watch?v=o5jq..." class="relative w-full px-1 outline-blue-500 py-3 border text-left pl-3 text-md font-normal rounded-lg">
                            </div>
                        </section>
                    </form>