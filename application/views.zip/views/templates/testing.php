<!DOCTYPE html>
<html lang="en" :class="isDark ? 'dark' : 'light'" x-data="{ isDark: false }">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Dandi Apriadi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/style.css" rel="stylesheet">
    <meta name="author" content="Dandi Apriadi">
    <title><?=$title?></title>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

</head>

<body class="font-montserrat text-sm bg-white dark:bg-zinc-900 " >
    <div class="flex min-h-screen  2xl:mx-auto 2xl:border-x-2 2xl:border-gray-200 dark:2xl:border-zinc-700 ">
        <!-- Left Sidebar -->
        <?=$sidebar?>
        <!-- Left Sidebar -->

        <main class=" flex-1 py-10  px-5 sm:px-10 ">

            <header class=" font-bold text-lg flex items-center  gap-x-3 md:hidden mb-12 relative pl-10">
                <span id="button-sidebar" onclick="MenuSidebar();" class="mr-6 transition-all duraton-1000 hover:text-red z-50 absolute left-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-gray-700 dark:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                      </svg>
                </span>

            </header>
           
            <section>
            <div class="mx-auto mt-8 flex items-start justify-center">

            <!-- Left Column (Image) -->
            <div class="w-1/3 pr-8">
              <img src="https://source.unsplash.com/random/800x600/?company" alt="Profile" class="w-full h-auto object-cover rounded-md">
            </div>

            <!-- Right Column (Information) -->
            <div class="w-2/3 pl-8">

              <div class="mb-4">
                <h1 class="text-2xl font-semibold text-gray-800">John Doe</h1>
                <p class="text-gray-600">Web Developer</p>
              </div>

              <!-- User Information Form -->
              <form>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                  <!-- First Name -->
                

                
                  <!-- Social Media Links -->


                </div>

                <!-- Submit Button -->
                <div class="mt-6">
                  <button type="submit" class="bg-blue-500 text-white p-2 rounded-md">Save Changes</button>
                </div>
              </form>
            </div>
            </div>

            </section>

        </main>

    </div>

</body>

</html>

<input type="number" value="0" class="hidden" id="menu-indicator-sidebar">

<script>
var indicatorSidebar = $("#menu-indicator-sidebar");
var sidebar = $("#sidebar");
var buttonSidebar = $("#button-sidebar");


    function MenuSidebar(){
    if(indicatorSidebar.val() == 0){
        sidebar.css("left","1px")
        buttonSidebar.css('left','200px')
        indicatorSidebar.val(1);
    }else{
        sidebar.css("left","")
        buttonSidebar.css('left','')
        indicatorSidebar.val(0);
        }
    }
</script>