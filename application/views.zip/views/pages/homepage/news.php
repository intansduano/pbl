
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?=$title?></title>
  <style>
    ::-webkit-scrollbar {
    width: 10px; /* Lebar scrollbar */
    background-color: transparent; /* Warna latar belakang scrollbar */
  }
  
  ::-webkit-scrollbar-thumb {
    background-color: transparent; /* Warna thumb (bagian yang dapat digerakkan) scrollbar */
  }
  
  ::-webkit-scrollbar-track {
    background-color: transparent; /* Warna track (bagian yang tidak dapat digerakkan) scrollbar */
  }
  .scrollbar {
    scrollbar-color: transparent transparent; /* Warna thumb dan track scrollbar */
    scrollbar-width: thin; /* Lebar scrollbar */
  }

  .course-card{
    background-color: #F3F4F6;
  }
  .course-image {
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
  }

  .swiper-slide {
    background-size: cover;
    background-position: center;
    text-align: center;
  }

  .my-popup-size {
  width: 400px;
  height: 150px;
  font-size: 12px;
  }

  </style>
</head>
<body class="bg-white">
  
  <section class="w-full md:px-10">
    <!-- search box -->

    <div class="pt-4 text-gray-800">
      <div class="w-full mx-auto">
        <div class="md:flex md:flex-row-reverse md:items-center">
          <div class="relative md:w-80">
            <input id="searchbox" type="text" class="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:border-blue-500" placeholder="Cari...">
            <button class="absolute top-0 right-0 mt-2 mr-2 focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" class="mt-1" height="20" width="20" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="py-4 w-full mx-auto">

    <div id="main-content w-full mx-auto" class="mb-7">
          <!-- Trending -->
          <h1 class="text-3xl font-bold ml-2 md:ml-10">PBL - <?=$_SESSION['jurusan']?></h1>

          <div id="vidio-terbaru" class="w-full px-2 h-auto overflow-auto pb-5 grid grid-cols-1 md:grid-cols-2 gap-5 md:px-4 py-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">

          </div>
          
    </div>
    
  </section>
</body>
</html>

<script>

  document.addEventListener('DOMContentLoaded', function() {
    showVidioTerbaru();
  });


  function showVidioTerbaru(){
      $.ajax({
          url: "<?php echo base_url('Vidio/getVidioJurusan'); ?>",
          type: "GET",
          dataType: 'json',
          data: {},
          success: function(response) {
              $.each(response.data, function(index, item) {
                  $("#vidio-terbaru").append(`
                       <a href="${item.urlselengkapnya}" class="relative">
                        <div class="bg-white border relative rounded-lg shadow-md hover:scale-105 transition-all duration-300 w-full h-auto">
                              <div class="h-full mb-20 pb-10 relative">
                              <img class="h-72 w-full rounded-t-lg border" src="${item.img}">
                              <div class="bg-white shadow-sm text-gray-800 font-semibold rounded-md px-2 absolute top-1 left-1 w-auto z-50">${item.tanggal}</div>
                              <div>
                              <div class=" h-20 w-full overflow-auto scrollbar">
                              <h1 class="text-xl font-bold ml-2">${item.judul}</h1>
                              </div>
                              <div class="h-6 w-72 absolute left-0 right-0 bottom-0 mx-auto py-2">
                                  <div class="grid grid-cols-3 mx-auto px-4 ml-8">
                                      <div><i class="fa-solid fa-eye"></i> ${item.view}</div>
                                      <div><i class="fa-solid fa-thumbs-up"></i> ${item.like}</div>
                                      <div><i class="fa-solid fa-comment"></i> ${item.comment}</div>
                                  </div>
                                  <div class="text-center">
                                      <hr class="my-2 bg-blue-500 h-1">
                                      <h1 class="font-semibold">${item.kategori}</h1>  
                                  </div>
                              </div>
                              </div>
                              </div>
                          </div>
                        </a>
                      `
                  );
              });
          }
      });
  }
  var search = document.getElementById("searchbox");
    search.addEventListener('keyup', function () {
        var Key = search.value;
        $.ajax({
          url: "<?php echo base_url('Vidio/searchVidioJurusan'); ?>",
          type: "GET",
          dataType: 'json',
          data: {
            key : Key
          },
          success: function(response) {
            $("#vidio-terbaru").empty();
            $.each(response.data, function(index, item) {
                    $("#vidio-terbaru").append(`
                        <div class="bg-white border  custom-card relative rounded-lg shadow-sm w-full h-auto">
                            <div class="h-full mb-20 pb-14 relative"> 
                                <img class="h-72 w-full rounded-t-lg border" src="${item.img}">
                                <div class="bg-white shadow-sm text-gray-800 font-semibold rounded-sm px-2 absolute top-2 left-1 w-auto z-50">${item.tanggal}</div>
                                <div class='overlay h-72'>
                                    <div class='overlay-content'>
                                        <a href="${item.urlselengkapnya}" class="mt-4 cursor-pointer bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">Selengkapnya</a>
                                    </div>
                                </div>
                            <div>
                            <div class=" h-20 w-full overflow-auto scrollbar">
                              <h1 class="text-xl font-bold ml-2">${item.judul}</h1>
                              </div>
                                <div class="h-6 w-72 absolute left-0 right-0 bottom-7 mx-auto py-2 pb-10 mb-3">
                                    <div class="grid grid-cols-3 mx-auto px-4 ml-8">
                                        <div><i class="fa-solid fa-eye"></i> ${item.view}</div>
                                        <div><i class="fa-solid fa-thumbs-up"></i> ${item.like}</div>
                                        <div><i class="fa-solid fa-comment"></i> ${item.comment}</div>
                                    </div>
                                    <div class="text-center">
                                        <hr class="my-2 bg-blue-500 h-1">
                                        <h1 class="font-semibold">${item.kategori}</h1>  
                                    </div>
                                </div>
                            </div>
                        </div>
                        `
                    );
                });
            }
      });
    }); 
</script>