<?php 

$message = $this->session->flashdata('msg_sweetalert');

if (isset($message)) {
	echo $message;
	$this->session->unset_userdata('msg_sweetalert');
}

?>

<!DOCTYPE html>
   <html lang="en">

   <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:wght@300;400;500;600;700&family=Rokkitt:wght@600;700&display=swap"
        rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                fontFamily: {
                    sans: ['Mulish', 'sans-serif'],
                    mono: ['Rokkitt', 'monospace'],
                },
            },
        }
    </script>
    <title><?=$title?></title>
</head>
   <body class="absolute top-0 w-full">
   <form action="" method="post">
   <div class="flex items-center justify-center min-h-screen bg-blue-100">
        <!-- Card Container -->
        <div
            class="relative flex flex-col m-6 space-y-10 bg-white shadow-2xl rounded-2xl md:flex-row md:space-y-0 md:m-0">
            <!-- Left Side -->
            <div class="p-6 md:p-20">
                <!-- Top Content -->
                <h2 class="font-mono mb-5 text-4xl font-bold">Log In</h2>
                <p class="max-w-sm mb-12 font-sans font-light text-gray-600">Login ke Akun yang telah Terdaftar pada Website Kami.</p>
                <input type="email" id="email" name="email" placeholder="someone@gmail.com" autocomplete="off" required
                    class="w-full p-6 border border-gray-300 rounded-md placeholder:font-sans placeholder:font-light">
               <input type="password" id="password" name="password" placeholder="Password" autocomplete="off" required
               class="w-full p-6 border border-gray-300 rounded-md placeholder:font-sans mt-4 placeholder:font-light">
                <div class="flex flex-col items-center justify-between mt-6 space-y-6 md:flex-row md:space-y-0">
                    <button
                        class="w-full md:w-auto flex justify-center items-center p-6 space-x-4 font-sans font-bold text-white rounded-md shadow-lg px-9 bg-blue-500 shadow-blue-100 hover:bg-opacity-90 shadow-sm hover:shadow-lg border transition hover:-translate-y-0.5 duration-150">
                        <span>Login</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-7" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <line x1="5" y1="12" x2="19" y2="12" />
                            <line x1="13" y1="18" x2="19" y2="12" />
                            <line x1="13" y1="6" x2="19" y2="12" />
                        </svg>
                    </button>
                </div>
                <!-- Border -->
                <div class="mt-12 border-b border-b-gray-300"></div>
                <!-- Bottom Content -->
                <p class="py-6 text-sm font-thin text-center text-gray-400">belum punya akun?</p>
                <!-- Bottom Buttons Container -->
                <div class="mx-auto">
                    <a href="<?=base_url('registrasi');?>"
                        class="flex mx-auto items-center hover:bg-blue-500 justify-center py-2 space-x-3 font-semibold hover:text-white border border-gray-300 rounded shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition duration-150 md:w-1/2">
                        <span class="">Daftar</span>
                     </a>
                </div>
            </div>
             <!-- Right Side -->
             <img src="https://images.unsplash.com/photo-1666361759686-ce64c9e1d1b9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
                alt="" class="w-[430px] hidden md:block md:rounded-r-2xl" />

            <!-- Close button -->
        </div>
    </div>
   </form>
   </body>
</html>

<script src="<?= base_url('assets/dashboard/dist/js/adminlte.min.js') ?>"></script>
