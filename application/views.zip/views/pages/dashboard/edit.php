<?php 

$message = $this->session->flashdata('msg_sweetalert');

if (isset($message)) {
	echo $message;
	$this->session->unset_userdata('msg_sweetalert');
}

?>


<!DOCTYPE html>
<html lang="en" :class="isDark ? 'dark' : 'light'" x-data="{ isDark: false }">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Dandi Apriadi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/style.css" rel="stylesheet">
    <meta name="author" content="Dandi Apriadi">
    <title><?=$title?></title>
  <script src="https://cdn.ckeditor.com/4.20.1/standard/ckeditor.js"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

</head>

<body class="font-montserrat text-sm bg-white dark:bg-zinc-900 " >
    <div class="flex min-h-screen  2xl:mx-auto 2xl:border-x-2 2xl:border-gray-200 dark:2xl:border-zinc-700 ">
        <!-- Left Sidebar -->
        <?=$sidebar?>
        <!-- Left Sidebar -->

        <main class=" flex-1 py-10  px-5 sm:px-10 ">
            <header class=" font-bold text-lg flex items-center  gap-x-3 md:hidden mb-12 relative pl-10">
                <span id="button-sidebar" onclick="MenuSidebar();" class="mr-6 transition-all duraton-1000 hover:text-red z-50 absolute left-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-gray-700 dark:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                      </svg>
                </span>

            </header>
            <section class="relative">
                <div>
                <div class="container my-6 px-2 relative mx-auto md:px-6">
                    <form method="post" action="" enctype="multipart/form-data">
                        <!-- save button -->
                        <button class="bg-transparent  md:absolute right-0 -top-10 hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">
                        Simpan Video
                        </button>

                        <input type="number" name="element" readonly value="3" id="element" class="hidden">    

                        <section id="main-element" class="mb-32 mt-2">
                        <div class="mx-auto text-center mb-4">
                            <input required class="relative w-full md:w-[80%] px-4 outline-blue-500 py-2 left-0 right-0 mx-auto border text-center text-2xl font-semibold rounded-lg" type="text" name="artikel-title" id="artikel-title" placeholder="Judul Video Anda" value="<?=$pbl->judul_pbl?>">
                            <?php echo form_error('artikel-title', '<h1 class="absolute ml-10 bg-black text-md mt-20"><font class="text-blue-100 mt-20"></font></h1>'); ?>
                        </div>
                        
                        <!--Element 1-->
                        <div id="element-1" class="mb-5 flex flex-wrap">
                            <!-- left image -->
                            <div class="mb-6 w-full shrink-0 grow-0 basis-auto lg:mb-0 lg:w-6/12 lg:pr-6">
                            <div class="relative">
                                <div class="ripple mb-2 relative overflow-hidden rounded-lg border h-96 bg-cover bg-[50%] bg-no-repeat shadow-lg dark:shadow-black/20">
                                    <div id="text-1" class="absolute w-full text-center mt-40 font-semibold text-gray-400/70 text-2xl h-full">
                                        <h2>Silahkan Memilih Gambar</h2> <span class="text-sm font-normal">Maximal 5Mb</span>
                                    </div>
                                    <img id="preview-image-1" src="<?=base_url('assets/images/thumbnail/'.$pbl->sampul);?>" alt="Preview Gambar" class="w-full h-full">
                                    <div class="absolute top-0 right-0 bottom-0 left-0 h-full w-full overflow-hidden bg-[hsl(0,0%,98.4%,0.2)] bg-fixed opacity-0 transition duration-300 ease-in-out hover:opacity-100"></div>
                                </div>
                                <div class="z-50 mx-auto">
                                    <input type="file" accept=".jpeg, .jpg, .png" name="Image-1" class="hidden" id="Image-1" onchange="previewImage(1)">
                                    <label class="bg-transparent md:absolute right-0 hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded" for="Image-1">Pilih Sampul Video</label>
                                </div>
                                </div>
                            </div>
                            <!-- left image -->

                            <!-- left deskription -->
                            <div class="w-full shrink-0 grow-0 basis-auto lg:w-6/12 lg:pl-6">
                            
                            <!-- kategori -->
                            <div class="grid grid-cols-2 gap-2">
                            <div class="mb-2">
                                <select id="artikel-kategori" name="artikel-kategori" class="bg-gray-50 border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                    <option disabled>Pilih Jurusan</option>
                                    <option value="<?=$pbl->jurusan?>"><?=$pbl->jurusan?></option>
                                    <option disabled>---------------</option>
                                    <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                                    <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                                    <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                                    <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                                </select>
                            </div>
                            <div class="mb-2">
                                <input type="text" value="<?=$pbl->status?>" readonly class="border border-gray-300 text-gray-900 text-md rounded-lg outline-none block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            </div>

                            
                            </div>
                            <div class="grid grid-cols-2 gap-2">
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Dosen Pengampuh MK</div>
                                    <input type="text" value="<?=$pbl->dosen_pengampuh_mk?>" name="dosen-pengampuh" placeholder="Contoh: Object Oriented Programming" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mitra</div>
                                    <input type="text" value="<?=$pbl->nama_mitra?>" name="nama-mitra" placeholder="Contoh: Politeknik Negeri Manado" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                            </div>

                            <!-- Deskripsi -->
                            <div class="mb-3">
							<div class="mb-3">
                                    <textarea required name="artikel-deskripsi-1" id="artikel-deskripsi-1" cols="30" rows="16" placeholder="Deskripsi Video Anda.."><?=html_entity_decode($pbl->deskripsi)?></textarea>
                                </div>
                            </div>
                            
                            </div>

                            <div class="w-full h-auto relative">
                                <input type="number" value="<?=$jumlah?>" class="hidden" name="jumlah-mahasiswa" id="jumlah-mahasiswa">
                                <div class="text-gray-600 mb-4 font-bold uppercase">Mahasiswa Terlibat</div>
                                    <div id="mahasiswa-terlibat" class="grid grid-cols-3 mb-4 gap-4">
                                        <?php $index=0; foreach ($mahasiswa->result() as $item) { $index++;?>
                                            <input type="text" value="<?=$item->no?>" class="hidden" name="no-<?=$index?>" id="no-<?=$index?>">
                                            <div id='nama-<?=$index?>' class="mb-2">
                                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mahasiswa <?=$index?></div>
                                            <input type="text" value="<?=$item->nama?>" placeholder="Nama Mahasiswa <?=$index?>" id="nama-mahasiswa-<?=$index?>" name="nama-mahasiswa-<?=$index?>" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                            </div>
                                            <div id='program-studi-<?=$index?>' class="mb-2">
                                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Program Studi</div>
                                                <select id="program-studi-<?=$index?>" name="program-studi-<?=$index?>" class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                    <option value="<?=$item->prodi?>"><?=$item->prodi?></option>
                                                    <option disabled>---------------</option>
                                                    <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                                                    <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                                                    <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                                                    <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                                                </select>
                                            </div>
                                            <div id='nim-<?=$index?>' class="mb-2">
                                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nim</div>
                                                <input type="text" value="<?=$item->nim?>" id="nim-mahasiswa-<?=$index?>" name="nim-mahasiswa-<?=$index?>" placeholder="Contoh: 21024137" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                            </div>
                                        <?php }?>
                                    </div>
                                    </div>

                                </div>

                            <div class="mb-2">
                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Original Link</div>
                                <input name="original-link" id="original-link" type="text" placeholder="Contoh: <iframe width='560' height='315' src='https://www.youtube.com/embed/fSE4laODlng?si=t_WqD1XcIv6A01d5' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe>" class="relative w-full px-1 outline-blue-500 py-3 border text-left pl-3 text-md font-normal rounded-lg">
                           <div class="mt-4 mb-4">
                           <a onclick="extractLink();" class="bg-transparent mx-auto cursor-pointer hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">
                                Extract Link
                                </a>
                           </div>
                            </div>
                         
                            <div>
                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Link</div>
                                <input name="link" value="<?=$pbl->link?>" id="link" required type="text" placeholder="Contoh: https://www.youtube.com/watch?v=o5jq..." class="relative w-full px-1 outline-blue-500 py-3 border text-left pl-3 text-md font-normal rounded-lg">
                            </div>
                        </section>
                    </form>
                    </div>
                    <div class="mt-2">
                        <h2 class="text-2xl font-bold mb-4">Komentar Reviewer</h2>
                        <!-- Daftar Komentar -->
                        <div id="display-chat" class="grid grid-cols-1 max-h-screen md:grid-cols-2 lg:grid-cols-3 gap-4 overflow-auto scrollbar">

                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>

</body>

</html>

<input type="number" value="0" class="hidden" id="menu-indicator-sidebar">
<input type="text" value="<?=$pbl->no_pbl?>" class="hidden" id="pbl">

<script>
CKEDITOR.replace('artikel-deskripsi-1');

var indicatorSidebar = $("#menu-indicator-sidebar");
var sidebar = $("#sidebar");
var buttonSidebar = $("#button-sidebar");

    function MenuSidebar(){
        if(indicatorSidebar.val() == 0){
            sidebar.css("left","1px")
            buttonSidebar.css('left','200px')
            indicatorSidebar.val(1);
        }else{
            sidebar.css("left","")
            buttonSidebar.css('left','')
            indicatorSidebar.val(0);
        }
    }
    function previewImage(data) {
        var input = document.getElementById('Image-'+data);
        var preview = document.getElementById('preview-image-'+data);
        var text = document.getElementById('text-'+data);
        var file = input.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            text.style.display="none";
        };

        reader.readAsDataURL(file);
    }

    function extractLink(){
    var originalLink = $("#original-link").val();
    $.ajax({
        url: "<?php echo base_url('Vidio/extractLink'); ?>",
        type: "POST",
        dataType: 'json',
        data: {
            link: originalLink
        },
        success: function(response) {
            $("#link").val(response);
         }
    });
   }

    document.addEventListener('DOMContentLoaded', function() {
        showComment();
    });


    function showComment(){
        var pbl = $("#pbl").val();
        $.ajax({
            url: "<?php echo base_url('Vidio/showComment/'); ?>"+pbl,
            type: "GET",
            dataType: 'json',
            success: function(response) {
                $("#display-chat").empty();
                $.each(response.data, function(index, item) {
                    $("#display-chat").append(`
                    <div class="bg-white border relative p-4 rounded-md shadow-md pb-16">
                    <input value="${item.id_comment}" class="hidden" id="comment-${index}" type="text">
                        <div class="flex items-center mb-4">
                            <img src="${item.profile}" class="w-8 h-8 rounded-full mr-2">
                            <div>
                                <h3 class="text-sm font-semibold">${item.nama_pengguna} </h3>
                            </div>
                            <div class="absolute right-2 top-1">
                            <span class="text-xs text-gray-600">${item.tanggal}</span>
                            </div>
                        </div>
                        <div class="h-auto w-full mb-2">
                        <p class="text-gray-700">${item.isi}</p>
                        </div>
                        <div id="comment-card-${index}" class="absolute bottom-0 text-center h-10 w-20 right-1 mx-auto ">
                        </div>
                    </div>
                `);
                });
            }   
        });
    }

</script>

<script src="https://cdn.ckeditor.com/4.20.1/standard/ckeditor.js"></script>
