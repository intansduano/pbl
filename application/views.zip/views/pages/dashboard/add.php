<?php 

$message = $this->session->flashdata('msg_sweetalert');

if (isset($message)) {
	echo $message;
	$this->session->unset_userdata('msg_sweetalert');
}

?>


<!DOCTYPE html>
<html lang="en" :class="isDark ? 'dark' : 'light'" x-data="{ isDark: false }">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Dandi Apriadi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/style.css" rel="stylesheet">
    <meta name="author" content="Dandi Apriadi">
  <script src="https://cdn.ckeditor.com/4.20.1/standard/ckeditor.js"></script>
    <title><?=$title?></title>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

</head>

<body class="font-montserrat text-sm bg-white dark:bg-zinc-900 " >
    <div class="flex min-h-screen 2xl:mx-auto 2xl:border-x-2 2xl:border-gray-200 dark:2xl:border-zinc-700 ">
        <!-- Left Sidebar -->
        <?=$sidebar?>
        <!-- Left Sidebar -->

        <main class=" flex-1 py-3 px-5 sm:px-10 ">
            <header class=" font-bold text-lg flex items-center  gap-x-3 md:hidden mb-12 relative pl-10">
                <span id="button-sidebar" onclick="MenuSidebar();" class="mr-6 transition-all duraton-1000 hover:text-red z-50 absolute left-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-gray-700 dark:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                      </svg>
                </span>

            </header>
            <section class="relative">
           
                <div>

                <div class="container my-5 px-2 relative mx-auto md:px-6">
                    <form method="post" action="" enctype="multipart/form-data">
                        <!-- save button -->
                        <button class="bg-transparent  md:absolute right-0 hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">
                        Simpan Video
                        </button>

                        <input type="number" name="element" readonly value="3" id="element" class="hidden">    

                        <section id="main-element" class="mb-32 mt-2">
                        <div class="mx-auto text-center mb-4">
                            <input required class="relative w-full md:w-[80%] px-4 outline-blue-500 py-2 left-0 right-0 mx-auto border text-center text-2xl font-semibold rounded-lg" type="text" name="artikel-title" id="artikel-title" placeholder="Judul Video Anda" value="<?= set_value('artikel-title')?>">
                            <?php echo form_error('artikel-title', '<h1 class="absolute ml-10 bg-black text-md mt-20"><font class="text-blue-100 mt-20"></font></h1>'); ?>
                        </div>
                        
                        <!--Element 1-->
                        <div id="element-1" class="mb-5 flex flex-wrap">
                            <!-- left image -->
                            <div class="mb-6 w-full shrink-0 grow-0 basis-auto lg:mb-0 lg:w-6/12 lg:pr-6">
                            <div class="relative">
                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Sampul Video</div>
                                <div class="ripple mb-2 relative overflow-hidden rounded-lg border h-96 bg-cover bg-[50%] bg-no-repeat shadow-lg dark:shadow-black/20">
                                    <div id="text-1" class="absolute w-full text-center mt-40 font-semibold text-gray-400/70 text-2xl h-full">
                                        <h2>Silahkan Memilih Gambar</h2> <span class="text-sm font-normal">Maximal 5Mb</span>
                                    </div>
                                    <img id="preview-image-1" src="#" alt="Preview Gambar" class="hidden w-full h-full">
                                    <div class="absolute top-0 right-0 bottom-0 left-0 h-full w-full overflow-hidden bg-[hsl(0,0%,98.4%,0.2)] bg-fixed opacity-0 transition duration-300 ease-in-out hover:opacity-100"></div>
                                </div>
                                <div class="z-50 mx-auto">
                                    <input type="file" accept=".jpeg, .jpg, .png" required name="Image-1" class="hidden" id="Image-1" onchange="previewImage(1)">
                                    <label class="bg-transparent md:absolute right-0 hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded" for="Image-1">Pilih Sampul Video</label>
                                </div>
                                </div>
                            </div>
                            <!-- left image -->

                            <!-- left deskription -->
                            <div class="w-full shrink-0 grow-0 basis-auto lg:w-6/12 lg:pl-6">
                            
                            <!-- kategori -->
                            <div class="grid grid-cols-2 gap-2">
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Program Studi</div>
                                    <select id="artikel-kategori" name="artikel-kategori" class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                        <option disabled>Program Studi</option>
                                        <option disabled>---------------</option>
                                        <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                                        <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                                        <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                                        <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Status</div>
                                <input type="text" value="Private" readonly class="border border-gray-300 text-gray-900 text-md rounded-lg outline-none block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-2">
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Dosen Pengampuh MK</div>
                                    <input type="text" name="dosen-pengampuh" placeholder="Contoh: Nama Dosen Pengampuh" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mitra</div>
                                    <input type="text" name="nama-mitra" placeholder="Contoh: Politeknik Negeri Manado" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                </div>
                            </div>

                            <!-- Deskripsi -->
                            <div class="mb-3">
                                <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Deskripsi / Latar Belakang Pemilihan proyek / latar belakang pemilihan lokasi</div>
                                    <textarea required required name="artikel-deskripsi-1" id="artikel-deskripsi-1" cols="30" rows="16" placeholder="Deskripsi Video Anda.." ></textarea>
                                </div>
                            </div>
                            
                            </div>

                            <div class="w-full h-auto relative">
                                <input type="number" value="1" class="hidden" name="jumlah-mahasiswa" id="jumlah-mahasiswa">
                                <a onclick="addMahasiswa();" class="bg-transparent  md:absolute right-16 hover:bg-blue-500 text-blue-700 font-semibold cursor-pointer hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">Tambah</a>
                                <a onclick="removeMahasiswa();" class="bg-transparent  md:absolute right-0 hover:bg-red-500 cursor-pointer text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">Hapus</a>
                                <div class="text-gray-600 mb-4 font-bold uppercase">Mahasiswa Terlibat</div>
                                    <div id="mahasiswa-terlibat" class="grid grid-cols-3 mb-4 gap-4">

                                        <div id='nama-1' class="mb-2">
                                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mahasiswa 1</div>
                                            <input type="text" placeholder="Nama Mahasiswa 1" id="nama-mahasiswa-1" name="nama-mahasiswa-1" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                        </div>
                                        <div id='program-studi-1' class="mb-2">
                                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Program Studi</div>
                                            <select id="program-studi-1" name="program-studi-1" class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                                <option disabled>Program Studi</option>
                                                <option disabled>---------------</option>
                                                <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                                                <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                                                <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                                                <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                                            </select>
                                        </div>
                                        <div id='nim-1' class="mb-2">
                                            <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nim</div>
                                            <input type="text" id="nim-mahasiswa-1" name="nim-mahasiswa-1" placeholder="Contoh: 21024137" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                        </div>
                                        
                                    </div>

                                </div>
                                
                                <div class="mb-2">
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Original Link</div>
                                    <input name="original-link" id="original-link" type="text" placeholder="Contoh: <iframe width='560' height='315' src='https://www.youtube.com/embed/fSE4laODlng?si=t_WqD1XcIv6A01d5' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe>" class="relative w-full px-1 outline-blue-500 py-3 border text-left pl-3 text-md font-normal rounded-lg">
                                </div>
                                <div class="mt-4 mb-4">
                                    <a onclick="extractLink();" class="bg-transparent mx-auto cursor-pointer hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-1 px-2 border border-blue-500 hover:border-transparent rounded">
                                    Extract Link
                                    </a>
                                </div>
                            
                                <div>
                                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Link</div>
                                    <input name="link" id="link" required type="text" placeholder="Contoh: https://www.youtube.com/watch?v=o5jq..." class="relative w-full px-1 outline-blue-500 py-3 border text-left pl-3 text-md font-normal rounded-lg">
                                </div>

                            </div>
                           
                        </section>
                    </form>
                    </div>
                </div>

            </section>
        </main>
    </div>

</body>

</html>

<input type="number" value="0" class="hidden" id="menu-indicator-sidebar">

<script>
var indicatorSidebar = $("#menu-indicator-sidebar");
var sidebar = $("#sidebar");
var buttonSidebar = $("#button-sidebar");

    function MenuSidebar(){
        if(indicatorSidebar.val() == 0){
            sidebar.css("left","1px")
            buttonSidebar.css('left','200px')
            indicatorSidebar.val(1);
        }else{
            sidebar.css("left","")
            buttonSidebar.css('left','')
            indicatorSidebar.val(0);
        }
    }
    function previewImage(data) {
        var input = document.getElementById('Image-'+data);
        var preview = document.getElementById('preview-image-'+data);
        var text = document.getElementById('text-'+data);
        var file = input.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            text.style.display="none";
        };

        reader.readAsDataURL(file);
    }
CKEDITOR.replace('artikel-deskripsi-1');
   
   function extractLink(){
    var originalLink = $("#original-link").val();
    $.ajax({
        url: "<?php echo base_url('Vidio/extractLink'); ?>",
        type: "POST",
        dataType: 'json',
        data: {
            link: originalLink
        },
        success: function(response) {
            $("#link").val(response);
         }
    });
   }
   var mahasiswa = $("#jumlah-mahasiswa");
   function addMahasiswa(){
        var currentValue = parseInt(mahasiswa.val());
        var newValue = currentValue < 20 ? currentValue + 1 : 20;
        if(newValue < 20){
            mahasiswa.val(newValue);
            $("#mahasiswa-terlibat").append(`
                <div id='nama-${newValue}' class="mb-2">
                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nama Mahasiswa ${newValue}</div>
                    <input type="text" placeholder="Nama Mahasiswa ${newValue}" id="nama-mahasiswa-${newValue}" name="nama-mahasiswa-${newValue}" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                </div>
                <div id='program-studi-${newValue}' class="mb-2">
                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Program Studi</div>
                    <select id="program-studi-${newValue}" name="program-studi-${newValue}" class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <option disabled>Program Studi</option>
                        <option disabled>---------------</option>
                        <option value="Sarjana Terapan Teknik Informatika">Sarjana Terapan Teknik Informatika</option>
                        <option value="Sarjana Terapan Teknik Listrik">Sarjana Terapan Teknik Listrik</option>
                        <option value="Diploma Tiga Teknik Listrik">Diploma Tiga Teknik Listrik</option>
                        <option value="Diploma Tiga Teknik Komputer">Diploma Tiga Teknik Komputer</option>
                    </select>
                </div>
                <div id='nim-${newValue}' class="mb-2">
                    <div class="text-gray-400 mb-2 ml-2 font-medium uppercase">Nim</div>
                    <input type="text" id="nim-mahasiswa-${newValue}" name="nim-mahasiswa-${newValue}" placeholder="Contoh: 21024137" required class="border border-gray-300 text-gray-900 text-md rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                </div>
        `);
        }
    }
    function removeMahasiswa(){
        var currentValue = parseInt(mahasiswa.val());
        if (currentValue > 1) {
        $("#nama-" + currentValue).remove();
        $("#program-studi-" + currentValue).remove();
        $("#nim-" + currentValue).remove();

        // Mengupdate nilai currentValue hanya jika lebih besar dari 2
        var newValue = currentValue > 2 ? currentValue - 1 : 1;
        mahasiswa.val(newValue);
    }
    }
</script>
<script src="https://cdn.ckeditor.com/4.20.1/standard/ckeditor.js"></script>
