<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$title?></title>
</head>
<body>
<!-- Container for demo purpose -->

<div class="container mx-auto mt-8 p-4">
        <!-- Video Player -->
        <div class="relative rounded-lg overflow-hidden mb-8">
            <!-- Video -->
            <iframe class="w-full h-[55vh]" src="<?=$pbl->link?>" frameborder="0" allowfullscreen></iframe>
        </div>

        <!-- Video Information -->
        <div class="flex items-center justify-between mb-4">
            <!-- Title -->
            <h2 class="text-3xl font-bold text-gray-800"><?=$pbl->judul_pbl?></h2>
            
            <!-- Share Button -->
        </div>
        <div class="text-gray-600 mb-4 font-semibold uppercase"><i class="fa-solid fa-location-dot"></i> <?=$pbl->nama_mitra?></div>

        <!-- Owner Information -->
        <div class="flex mx-auto relative justify-beatwean">
          <a href="<?=base_url('user/'.$penulis->username);?>">
            <div class="flex mb-4">
                <!-- Owner Photo -->
                <img src="<?=base_url('assets/images/profile/'.$penulis->profile);?>" alt="Owner Photo" class="w-10 h-10 rounded-full mr-4">
                <!-- Owner Name -->
                <p class="text-gray-700 font-semibold"><?=$penulis->firstname?> <?=$penulis->lastname?></p>
            </div>
          </a>
          <!-- Video Statistics -->
          <div class="flex mb-8 absolute right-0">
              <!-- Like Count -->
              <button onclick="like();" class="flex items-center bg-white py-2 mr-2 hover:scale-105 transition-all duration-300 group px-4 rounded-md shadow-md">
                  <i id="button-like" class="fa-solid fa-thumbs-up <?=$liked?> group-hover:text-blue-500"></i>
                <span id="likes" class="text-gray-700 ml-2"><?=$like?></span>
              </button>
          </div>
        </div>
        <div class="mt-3 mb-4">
            <div class="grid grid-cols-2 gap-3">
            <div>
            <p class="mb-3"><?=$view?> <i class="fas fa-eye"></i> - <span class="italic text-gray-600"><?=tanggal($pbl->tanggal);?></span></p>
            </div>
            <div class="text-right">
            <p class="text-gray-600 my-1 font-bold uppercase"><?=$pbl->dosen_pengampuh_mk?></p>
            </div>
            </div>
            <div class="text-gray-600 my-1 font-bold uppercase">Deskripsi / Latar Belakang</div>
            <p class="text-gray-600"><?=html_entity_decode($pbl->deskripsi)?></p>
        </div>
        <div class="text-gray-600 my-1 font-bold uppercase">Mahasiswa Terlibat</div>
        <div id="mahasiswa-terlibat" class="grid grid-cols-3 mb-4 gap-4">
        <?php $index=0; foreach ($mahasiswa->result() as $item) { $index++;?>
            <input type="text" value="<?=$item->no?>" class="hidden" name="no-<?=$index?>" id="no-<?=$index?>">
            <div class="mb-2">
            <div class="text-gray-500 mb-2 ml-2 font-normal lowecase">Nama Mahasiswa <?=$index?></div>
            <input type="text" value="<?=$item->nama?>"  readonly  class="border border-gray-300 text-gray-900 text-md rounded-lg outline-none cursor-default block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            </div>
            <div class="mb-2">
                <div class="text-gray-500 mb-2 ml-2 font-normal lowecase">Program Studi</div>
                <input type="text" value="<?=$item->prodi?>"  readonly  class="border border-gray-300 text-gray-900 text-md rounded-lg outline-none cursor-default block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            </div>
            <div class="mb-2">
                <div class="text-gray-500 mb-2 ml-2 font-normal lowecase">Nim</div>
                <input type="text" value="<?=$item->nim?>" readonly  class="border border-gray-300 text-gray-900 text-md rounded-lg outline-none cursor-default block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            </div>
        <?php }?>
    </div>
        <h2 class="text-2xl font-bold mb-4 mt-4">Video Serupa</h2>

        <!-- Similar Videos -->
        <div id="related-vidio" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
           
        </div>
    </div>

</body>
</html>
<input type="text" value="<?=$pbl->no_pbl?>" id="no_pbl" class="hidden">
<input type="text" value="<?=$liked?>" id="liked" class="hidden">
<input type="text" value="<?=$pbl->jurusan?>" id="jurusan" class="hidden">
<script>
  document.addEventListener('DOMContentLoaded', function() {
       showSimilarVidio();
    });

    function like(){
        var kode = $("#no_pbl").val();
        var liked = $("#liked").val();
        $.ajax({
            url: "<?php echo base_url('Vidio/likes'); ?>",
            type: "POST",
            dataType: 'json',
            data: {
                artikel: kode
            },
            success: function(response) {
                $("#likes").empty();
                $("#likes").append(response.like);
                $("#button-like").css('color',response.liked);
            }   
        });
    }

    function showSimilarVidio(){
      var Jurusan = $("#jurusan").val();
        $.ajax({
            url: "<?php echo base_url('Vidio/getSimilarVidio'); ?>",
            type: "GET",
            dataType: 'json',
            data: {
              jurusan : Jurusan
            },
            success: function(response) {
              $("#related-vidio").empty()
                $.each(response.data, function(index, item) {
                    $("#related-vidio").append(`

                    <a href="${item.urlselengkapnya}">
                      <div class="bg-white h-96 rounded-md hover:scale-105 transition-all duration-300 relative shadow-md overflow-hidden">
                          <img src="${item.img}" alt="" class="w-full h-36 object-cover">
                          <div class="p-4 pb-10">
                              <h3 class="text-lg font-bold text-gray-800">${item.judul}</h3>
                              <div>
                                <div class="h-6 w-72 absolute left-0 right-0 bottom-7 mx-auto py-2 pb-10 mb-3">
                                    <div class="grid grid-cols-3 mx-auto px-4 ml-8">
                                        <div><i class="fa-solid fa-eye"></i> ${item.view}</div>
                                        <div><i class="fa-solid fa-thumbs-up"></i> ${item.like}</div>
                                        <div><i class="fa-solid fa-comment"></i> ${item.comment}</div>
                                    </div>
                                    <div class="text-center">
                                        <hr class="my-2 bg-blue-500 h-1">
                                        <h1 class="font-semibold">${item.kategori}</h1>  
                                    </div>
                                </div>
                            </div>
                          </div>
                      </div>
                      
                    </a>
                        `
                    );
                });
            }
        });
    }
</script>